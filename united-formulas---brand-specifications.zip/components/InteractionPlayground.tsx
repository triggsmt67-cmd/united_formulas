
import React from 'react';

const InteractionPlayground: React.FC = () => {
  return (
    <div>
      <h2 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
        <span className="w-4 h-px bg-gray-400"></span> 03. Interaction & Depth
      </h2>
      <p className="text-sm text-gray-600 mb-8 max-w-2xl">
        Industrial interfaces must feel mechanical and responsive. We use snappy transitions and bioluminescent glows to guide user attention.
      </p>

      <div className="bg-midnight-sky p-6 md:p-10 rounded-sm relative overflow-hidden border-b-4 border-glacial-cyan">
        <div className="absolute top-0 right-0 w-full h-full bg-glow-gradient animate-pulse-slow pointer-events-none"></div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
          
          {/* 1. The Luma Border */}
          <div className="group cursor-pointer">
            <p className="text-[10px] font-mono text-gray-500 mb-2 uppercase tracking-widest">HOVER: LUMA BORDER</p>
            <div className="h-32 bg-gray-900/80 backdrop-blur-sm rounded-sm border border-gray-700 group-hover:border-glacial-cyan transition-colors duration-300 ease-snap flex items-center justify-center relative shadow-lg">
                <div className="text-center">
                    <span className="block text-white font-black uppercase text-xs tracking-tighter group-hover:text-glacial-cyan transition-colors">Tactile Feedback</span>
                    <span className="text-[8px] text-gray-600 font-mono mt-1 block">TRANSITION: SNAP</span>
                </div>
            </div>
          </div>

          {/* 2. The Atmospheric Glow */}
          <div className="group cursor-pointer">
            <p className="text-[10px] font-mono text-gray-500 mb-2 uppercase tracking-widest">HOVER: ATMOSPHERIC</p>
            <div className="h-32 bg-gray-900/80 backdrop-blur-sm rounded-sm border border-gray-800 shadow-lg group-hover:shadow-glow-cyan group-hover:-translate-y-1 transition-all duration-300 ease-snap flex items-center justify-center">
                <div className="text-center">
                    <span className="text-white font-black uppercase text-xs tracking-tighter">Bioluminescent</span>
                    <span className="text-[8px] text-gray-600 font-mono mt-1 block">ELEVATION: +4PX</span>
                </div>
            </div>
          </div>

          {/* 3. The Instrument Panel */}
          <div className="group cursor-pointer">
            <p className="text-[10px] font-mono text-gray-500 mb-2 uppercase tracking-widest">ACTIVE: INSTRUMENT</p>
            <div className="h-32 bg-gray-900/80 backdrop-blur-sm rounded-sm border border-gray-800 flex flex-col items-center justify-center gap-3">
              <button className="px-6 py-2 bg-gray-800 rounded-sm text-white text-[10px] font-mono border border-gray-700 shadow-inner-light hover:bg-alpine-green hover:border-alpine-green hover:shadow-glow-alpine transition-all duration-200 active:scale-95 active:bg-lichen-moss uppercase tracking-widest font-bold">
                Engage System
              </button>
              <span className="text-[9px] text-gray-600 font-mono uppercase">Backlit Simulation</span>
            </div>
          </div>

        </div>
      </div>

      {/* Tech Breakdown */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 bg-gray-50 border border-gray-200 rounded-sm">
          <h4 className="font-bold text-xs text-midnight-sky mb-2 uppercase tracking-tight">The "Snap" Bezier</h4>
          <p className="text-[11px] text-shale-gray leading-relaxed font-medium">
            Standard easings feel too soft for industrial applications. We use <code className="bg-gray-200 px-1 rounded text-[9px]">cubic-bezier(0.16, 1, 0.3, 1)</code> to create a mechanical engagement feeling—fast to start, heavy to finish.
          </p>
        </div>
        <div className="p-5 bg-gray-50 border border-gray-200 rounded-sm">
          <h4 className="font-bold text-xs text-midnight-sky mb-2 uppercase tracking-tight">Sub-surface Scattering</h4>
          <p className="text-[11px] text-shale-gray leading-relaxed font-medium">
            Shadows on dark surfaces should use color, not black. Apply <code className="bg-gray-200 px-1 rounded text-[9px]">shadow-glacial-cyan/20</code> to simulate the glow of an instrument panel in low light.
          </p>
        </div>
      </div>
    </div>
  );
};

export default InteractionPlayground;
