
import React, { useState } from 'react';
import { generateFormulaSpec, FormulaSpec } from '../services/geminiService';

const FormulaGenerator: React.FC = () => {
  const [keyword, setKeyword] = useState('');
  const [spec, setSpec] = useState<FormulaSpec | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!keyword.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const result = await generateFormulaSpec(keyword);
      setSpec(result);
    } catch (err) {
      setError('System Failure: Unable to synthesize specification at this time.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-limestone border border-gray-200 p-6 md:p-8 rounded-sm">
      <h2 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
        <span className="w-4 h-px bg-gray-400"></span> 04. AI Specification Synth
      </h2>
      
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="flex-1">
          <input 
            type="text" 
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="e.g. Pine needle solvent, Arctic lubricant..."
            className="w-full bg-white border border-gray-300 px-4 py-3 font-mono text-sm focus:outline-none focus:border-alpine-green focus:ring-1 focus:ring-alpine-green transition-all"
          />
          <p className="text-[9px] text-gray-400 mt-2 font-mono uppercase tracking-tighter">Enter base components for specification drafting.</p>
        </div>
        <button 
          onClick={handleGenerate}
          disabled={loading || !keyword.trim()}
          className="bg-midnight-sky text-white px-8 py-3 font-black text-xs uppercase tracking-widest hover:bg-glacial-cyan transition-colors disabled:opacity-50 disabled:cursor-not-allowed h-fit"
        >
          {loading ? 'Synthesizing...' : 'Draft Spec Sheet'}
        </button>
      </div>

      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 text-xs font-mono text-red-700 mb-8 animate-pulse">
            ERROR_LOG: {error}
        </div>
      )}

      {spec && (
        <div className="bg-white border-2 border-midnight-sky p-6 md:p-10 shadow-rugged relative overflow-hidden transition-all duration-500 opacity-100 translate-y-0">
          <div className="absolute top-2 right-2 flex flex-col items-end">
            <span className="text-[8px] font-mono text-gray-300 uppercase">Document UF-TECH-DOC</span>
            <div className="w-12 h-12 bg-gray-50 opacity-10 topo-pattern"></div>
          </div>

          <div className="border-b-2 border-gray-100 pb-4 mb-6">
            <h3 className="text-3xl font-black text-midnight-sky uppercase tracking-tighter">{spec.name}</h3>
            <p className="text-xs font-mono text-alpine-green font-bold uppercase tracking-widest mt-1">{spec.category} // {spec.toxicityRating}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h4 className="text-[10px] font-mono text-gray-400 uppercase mb-2">Technical Description</h4>
                <p className="text-sm text-shale-gray leading-relaxed italic">"{spec.technicalDescription}"</p>
              </div>

              <div>
                <h4 className="text-[10px] font-mono text-gray-400 uppercase mb-2">Key Components</h4>
                <ul className="grid grid-cols-1 gap-1">
                  {spec.keyIngredients.map((ing, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs font-bold text-midnight-sky uppercase">
                      <span className="w-1.5 h-1.5 bg-glacial-cyan rounded-full"></span> {ing}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-sm space-y-4">
              <div className="flex justify-between items-end border-b border-gray-200 pb-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase">Biodegradability</span>
                <span className="text-2xl font-black text-alpine-green tracking-tighter">{spec.biodegradability}</span>
              </div>
              <div className="bg-white p-4 border border-gray-200">
                 <h4 className="text-[9px] font-mono text-safety-orange font-black uppercase mb-2">Safety Protocol</h4>
                 <p className="text-[11px] font-medium text-gray-600 leading-tight font-mono">{spec.safetyInstructions}</p>
              </div>
              <div className="pt-2">
                  <div className="h-2 w-full bg-gray-200 overflow-hidden">
                      <div className="h-full bg-alpine-green" style={{ width: spec.biodegradability }}></div>
                  </div>
                  <p className="text-[8px] text-gray-400 mt-1 font-mono uppercase text-right">Sustainability Index Mapping</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FormulaGenerator;
