
import React from 'react';

interface SwatchProps {
  name: string;
  hex: string;
  className: string;
  description?: string;
  textColor?: string;
}

const Swatch: React.FC<SwatchProps> = ({ name, hex, className, description, textColor = 'text-gray-400' }) => (
  <div className="group cursor-pointer">
    <div className={`h-24 w-full shadow-inner border border-black/10 transition-transform duration-300 group-hover:scale-[1.02] ${className}`}></div>
    <div className="p-3 border border-t-0 border-gray-200 bg-white">
      <p className="font-bold text-xs md:text-sm text-midnight-sky whitespace-nowrap">{name}</p>
      <p className={`font-mono text-[9px] md:text-[10px] mt-1 uppercase ${textColor}`}>{hex}</p>
      {description && <p className="text-[9px] md:text-[10px] text-gray-500 mt-1 leading-tight">{description}</p>}
    </div>
  </div>
);

const LandscapePalette: React.FC = () => {
  return (
    <div>
      <h2 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
        <span className="w-4 h-px bg-gray-400"></span> 01. The Landscape Palette
      </h2>
      <p className="text-sm text-gray-600 mb-8 max-w-2xl font-medium leading-relaxed">
        Our identity is grounded in the Montana elements: deep sky, glacial water, shale rock, and dense pine forests. These colors provide a high-contrast industrial readability.
      </p>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 md:gap-4 mb-10">
        <Swatch name="Midnight Sky" hex="#0F172A" className="bg-midnight-sky" description="Primary Brand Body" />
        <Swatch name="Glacial Cyan" hex="#0891B2" className="bg-glacial-cyan" description="Industrial Accent" />
        <Swatch name="Alpine Green" hex="#15803D" className="bg-alpine-green" description="Eco Core" />
        <Swatch name="Safety Orange" hex="#EA580C" className="bg-safety-orange" description="Status High-Vis" />
        <Swatch name="Shale Gray" hex="#334155" className="bg-shale-gray" description="Primary Type" />
      </div>

      <h3 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">Base Layers & Foundations</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Swatch name="Limestone" hex="#F8FAFC" className="bg-limestone" description="Site Background" />
        <Swatch name="Pure White" hex="#FFFFFF" className="bg-white" description="Card/UI Surface" />
        <Swatch name="Cobalt Ore" hex="#1E3A8A" className="bg-cobalt-ore" description="Technical Deep" />
        <Swatch name="Lichen Moss" hex="#84CC16" className="bg-lichen-moss" description="Success Indicators" />
      </div>
    </div>
  );
};

export default LandscapePalette;
