
import React from 'react';

const TypographySection: React.FC = () => {
  return (
    <div>
      <h2 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-6 flex items-center gap-2">
        <span className="w-4 h-px bg-gray-400"></span> 02. Typography
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 bg-limestone p-6 md:p-10 border border-gray-200">
        {/* Main Font */}
        <div className="space-y-4">
          <div>
            <p className="text-[10px] font-mono text-gray-400 mb-2 uppercase tracking-tighter">THE WORKHORSE // DISPLAY & INTERFACE</p>
            <p className="text-5xl font-black text-midnight-sky mb-2 tracking-tight">Geist Sans</p>
          </div>
          <div className="border-t border-gray-200 pt-4">
            <p className="text-shale-gray text-sm leading-relaxed mb-4">
              Geometric, legible, and tough. Our primary typeface is designed for high-stakes readability. It looks like it was milled from raw steel, not drawn on a screen.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="text-xs font-black px-2 py-1 bg-midnight-sky text-white">BLACK</span>
              <span className="text-xs font-bold px-2 py-1 bg-gray-200">BOLD</span>
              <span className="text-xs font-medium px-2 py-1 bg-gray-200">MEDIUM</span>
              <span className="text-xs font-normal px-2 py-1 bg-gray-200">REGULAR</span>
            </div>
          </div>
        </div>

        {/* Mono Font */}
        <div className="space-y-4">
          <div>
            <p className="text-[10px] font-mono text-gray-400 mb-2 uppercase tracking-tighter">THE DATA // CODE & TECHNICALS</p>
            <p className="text-4xl font-mono text-cobalt-ore mb-2 tracking-tighter">Geist Mono</p>
          </div>
          <div className="border-t border-gray-200 pt-4">
            <div className="bg-white p-4 border-l-4 border-alpine-green text-xs font-mono text-shale-gray shadow-sm space-y-2">
              <div className="flex justify-between border-b border-gray-50 pb-1">
                <span>BATCH_ID:</span>
                <span className="text-midnight-sky font-bold">UF-2024-PX9</span>
              </div>
              <div className="flex justify-between border-b border-gray-50 pb-1">
                <span>VISCOSITY:</span>
                <span className="text-midnight-sky font-bold">14.2 CPS</span>
              </div>
              <div className="flex justify-between">
                <span>STATUS:</span>
                <span className="text-alpine-green font-bold">SYSTEM_OPTIMAL</span>
              </div>
            </div>
            <p className="text-[10px] text-gray-400 mt-4 font-mono italic leading-tight">
              Used exclusively for technical readouts, labels, and secondary identification.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TypographySection;
