
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="flex flex-col md:flex-row justify-between items-end mb-16 border-b-2 border-gray-100 pb-8 mt-4">
      <div>
        <h1 className="text-4xl font-black text-midnight-sky tracking-tight mb-2 uppercase">United Formulas</h1>
        <p className="text-sm font-mono text-gray-500 uppercase tracking-widest">Brand Spec v3.3 // Interactive Deck</p>
      </div>
      <div className="text-right mt-6 md:mt-0 flex flex-col items-end">
        <div className="text-[10px] font-bold text-white bg-alpine-green px-3 py-1 rounded-sm inline-block mb-1 tracking-wider uppercase">
          ECO-INDUSTRIAL CERTIFIED
        </div>
        <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-lichen-moss animate-pulse"></span>
            <p className="text-[10px] text-gray-400 font-mono uppercase">System Node: Missoula, MT</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
