
import { GoogleGenAI, Type } from "@google/genai";

export interface FormulaSpec {
  name: string;
  category: string;
  technicalDescription: string;
  biodegradability: string;
  toxicityRating: string;
  keyIngredients: string[];
  safetyInstructions: string;
}

const FORMULA_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "Professional industrial name for the formula" },
    category: { type: Type.STRING, description: "Industrial category (e.g., Solvent, Lubricant, Surface Agent)" },
    technicalDescription: { type: Type.STRING, description: "A high-level technical summary of the formula's action" },
    biodegradability: { type: Type.STRING, description: "Percentage of biodegradability (e.g., 98.4%)" },
    toxicityRating: { type: Type.STRING, description: "Safety rating (e.g., LOW-V2, NEUTRAL)" },
    keyIngredients: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List of 3-5 industrial ingredients" 
    },
    safetyInstructions: { type: Type.STRING, description: "Brief safety warning" }
  },
  required: ["name", "category", "technicalDescription", "biodegradability", "toxicityRating", "keyIngredients", "safetyInstructions"]
};

export const generateFormulaSpec = async (input: string): Promise<FormulaSpec> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = 'gemini-3-flash-preview';

  const systemInstruction = `
    You are the Senior Formulation Scientist at United Formulas, a Missoula-based eco-industrial firm. 
    Your tone is highly technical, authoritative, industrial, and deeply Montana-inspired (pine, rivers, rugged, cold).
    Generate a detailed technical specification for a formula based on user keywords.
    The response MUST be valid JSON.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: `Keyword: ${input}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: FORMULA_SCHEMA,
    },
  });

  try {
    return JSON.parse(response.text.trim()) as FormulaSpec;
  } catch (e) {
    throw new Error("Failed to parse technical specification.");
  }
};
