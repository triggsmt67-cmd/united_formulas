
import React, { useState } from 'react';
import Header from './components/Header';
import LandscapePalette from './components/LandscapePalette';
import TypographySection from './components/TypographySection';
import InteractionPlayground from './components/InteractionPlayground';
import FormulaGenerator from './components/FormulaGenerator';

const App: React.FC = () => {
  return (
    <div className="p-4 md:p-8 min-h-screen font-sans text-shale-gray">
      {/* MAIN CONTAINER */}
      <div className="max-w-4xl mx-auto bg-white shadow-2xl rounded-sm border-t-8 border-alpine-green relative overflow-hidden mb-12">
        
        {/* Background Texture Hint */}
        <div className="absolute top-0 right-0 w-96 h-96 topo-pattern rounded-bl-full pointer-events-none z-0"></div>

        <div className="relative z-10 p-6 md:p-12">
          <Header />
          
          <main className="space-y-24">
            <section id="landscape-palette">
              <LandscapePalette />
            </section>

            <section id="typography">
              <TypographySection />
            </section>

            <section id="interaction">
              <InteractionPlayground />
            </section>

            <section id="ai-generator">
              <FormulaGenerator />
            </section>
          </main>

          <footer className="mt-24 pt-8 border-t border-gray-100 text-center">
            <p className="text-[10px] md:text-xs text-gray-400 font-mono uppercase tracking-widest">
              Montana Industrial Design Core // Reliability . Sustainability . Activity
            </p>
            <p className="text-[8px] md:text-[10px] text-gray-300 mt-2 font-mono">
              © United Formulas v3.3-Stable. Distributed for internal specification review only.
            </p>
          </footer>
        </div>
      </div>
    </div>
  );
};

export default App;
